import React, { useState, useEffect, useRef } from 'react';
import { CalculationHistoryItem } from '../types';
import { pythonEngine, formatResultNumber, cleanFloat } from '../utils/pythonEvaluator';
import { Copy, Check, RotateCcw, ArrowRight, CornerDownLeft, Sparkles, Trash2, History } from 'lucide-react';

interface VisualCalculatorProps {
  onSendToRepl: (code: string) => void;
  history: CalculationHistoryItem[];
  onAddHistory: (item: CalculationHistoryItem) => void;
  onClearHistory: () => void;
}

export const VisualCalculator: React.FC<VisualCalculatorProps> = ({
  onSendToRepl,
  history,
  onAddHistory,
  onClearHistory,
}) => {
  const [expression, setExpression] = useState<string>('2 ** 8 + math.sqrt(144)');
  const [result, setResult] = useState<string>('268');
  const [error, setError] = useState<string | null>(null);
  const [memory, setMemory] = useState<number>(0);
  const [angleMode, setAngleMode] = useState<'rad' | 'deg'>('deg');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [copiedPython, setCopiedPython] = useState<boolean>(false);
  const [isCalculating, setIsCalculating] = useState<boolean>(false);
  const [formatMode, setFormatMode] = useState<'standard' | 'scientific' | 'hex' | 'bin'>('standard');
  const [showHistoryDrawer, setShowHistoryDrawer] = useState<boolean>(false);

  const inputRef = useRef<HTMLInputElement>(null);

  // Compute live or on demand
  const handleCalculate = async (exprToRun?: string) => {
    const expr = (exprToRun ?? expression).trim();
    if (!expr) {
      setResult('');
      setError(null);
      return;
    }

    setIsCalculating(true);
    setError(null);

    // Build python statement
    let pyCode = expr;
    // Adjust trig functions if in degree mode
    if (angleMode === 'deg') {
      pyCode = pyCode
        .replace(/math\.sin\(([^)]+)\)/g, 'math.sin(math.radians($1))')
        .replace(/math\.cos\(([^)]+)\)/g, 'math.cos(math.radians($1))')
        .replace(/math\.tan\(([^)]+)\)/g, 'math.tan(math.radians($1))');
    }

    try {
      const res = await pythonEngine.execute(pyCode);
      if (res.success && res.result !== null && res.result !== undefined) {
        const valStr = String(res.result);
        setResult(valStr);
        setError(null);

        // Record history
        onAddHistory({
          id: `${Date.now()}-${Math.random()}`,
          timestamp: new Date(),
          expression: expr,
          pythonCode: `import math\nresultado = ${expr}`,
          result: valStr,
          type: 'scientific',
        });
      } else {
        setError(res.stderr || 'Erro de sintaxe Python');
      }
    } catch (err: any) {
      setError(err?.message || 'Erro de cálculo');
    } finally {
      setIsCalculating(false);
    }
  };

  // Run initial calculation once
  useEffect(() => {
    handleCalculate('2 ** 8 + math.sqrt(144)');
  }, []);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if focus is in a text input or textarea
      if (document.activeElement?.tagName === 'TEXTAREA' || 
          (document.activeElement?.tagName === 'INPUT' && document.activeElement !== inputRef.current)) {
        return;
      }

      if (e.key === 'Enter') {
        e.preventDefault();
        handleCalculate();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        setExpression('');
        setResult('');
        setError(null);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [expression, angleMode]);

  const insertText = (text: string) => {
    setExpression((prev) => {
      // If result was shown and user clicks an operator, continue with previous result
      if (['+', '-', '*', '/', '**', '//', '%'].includes(text) && (!prev || prev === '0') && result) {
        return `${result} ${text} `;
      }
      return prev + text;
    });
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const handleBackspace = () => {
    setExpression((prev) => prev.slice(0, -1));
  };

  const handleClear = () => {
    setExpression('');
    setResult('');
    setError(null);
  };

  const handleCopyResult = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleCopyPython = () => {
    const code = `# Python Math Code\nimport math\n\nexpressao = ${expression || '0'}\nprint("Resultado:", expressao)`;
    navigator.clipboard.writeText(code);
    setCopiedPython(true);
    setTimeout(() => setCopiedPython(false), 2000);
  };

  // Formatted representations
  const getFormattedValue = () => {
    if (!result || error) return '0';
    const num = Number(result);
    if (isNaN(num)) return result;

    if (formatMode === 'scientific') {
      return num.toExponential(6);
    }
    if (formatMode === 'hex') {
      return Number.isInteger(num) ? `0x${num.toString(16).toUpperCase()}` : 'Requer número inteiro';
    }
    if (formatMode === 'bin') {
      return Number.isInteger(num) ? `0b${num.toString(2)}` : 'Requer número inteiro';
    }
    return formatResultNumber(num);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Sub-header context */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <span>Calculadora Matemática & Científica</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Calculadora com sintaxe Python pura, biblioteca <code className="text-amber-400 font-mono">math</code>, operadores <code className="text-amber-400 font-mono">**</code>, <code className="text-amber-400 font-mono">//</code> e tradução de código em tempo real.
          </p>
        </div>

        {/* Action buttons & Angle mode switch */}
        <div className="flex items-center gap-2">
          {/* Segmented control for Deg/Rad */}
          <div className="flex items-center p-1 bg-slate-900 border border-slate-800 rounded-lg">
            <button
              onClick={() => setAngleMode('deg')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                angleMode === 'deg' ? 'bg-amber-400 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              DEG (Graus)
            </button>
            <button
              onClick={() => setAngleMode('rad')}
              className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                angleMode === 'rad' ? 'bg-amber-400 text-slate-950 shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              RAD (Radianos)
            </button>
          </div>

          <button
            onClick={() => setShowHistoryDrawer(!showHistoryDrawer)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <History className="w-3.5 h-3.5 text-amber-400" />
            <span>Histórico ({history.length})</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Main Calculator Body */}
        <div className={`${showHistoryDrawer ? 'lg:col-span-8' : 'lg:col-span-12'} transition-all`}>
          <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
            
            {/* Display Area */}
            <div className="p-5 sm:p-6 bg-slate-950/70 border-b border-slate-800">
              
              {/* Python Syntax Header Indicator */}
              <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                <div className="flex items-center gap-2 font-mono">
                  <span className="text-amber-400">py &gt;&gt;&gt;</span>
                  <span className="text-slate-400 truncate max-w-xs sm:max-w-md">
                    {expression ? `resultado = ${expression}` : '# Digite ou clique para calcular'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {memory !== 0 && (
                    <span className="font-mono text-amber-400">M = {memory}</span>
                  )}
                  <button
                    onClick={handleCopyPython}
                    className="flex items-center gap-1 hover:text-amber-400 transition-colors text-slate-400"
                    title="Copiar código Python"
                  >
                    {copiedPython ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedPython ? 'Copiado!' : 'Copiar .py'}</span>
                  </button>
                </div>
              </div>

              {/* Expression Input */}
              <div className="relative mb-3">
                <input
                  ref={inputRef}
                  type="text"
                  value={expression}
                  onChange={(e) => setExpression(e.target.value)}
                  placeholder="ex: 15 * 4 + math.sqrt(81)"
                  className="w-full bg-transparent text-xl sm:text-2xl font-mono text-slate-100 placeholder-slate-600 focus:outline-none border-b border-transparent focus:border-amber-400/50 pb-1 tabular-nums"
                />
              </div>

              {/* Big Result Line */}
              <div className="flex items-baseline justify-between gap-4 pt-2 border-t border-slate-800/80">
                <div className="text-xs text-slate-400 flex items-center gap-1.5">
                  <span>Resultado:</span>
                  {/* Format switcher */}
                  <div className="inline-flex items-center gap-1 bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-[11px]">
                    <button
                      onClick={() => setFormatMode('standard')}
                      className={`hover:text-amber-300 ${formatMode === 'standard' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
                    >
                      Padrão
                    </button>
                    <span>·</span>
                    <button
                      onClick={() => setFormatMode('scientific')}
                      className={`hover:text-amber-300 ${formatMode === 'scientific' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
                    >
                      Científico
                    </button>
                    <span>·</span>
                    <button
                      onClick={() => setFormatMode('hex')}
                      className={`hover:text-amber-300 ${formatMode === 'hex' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
                    >
                      HEX
                    </button>
                    <span>·</span>
                    <button
                      onClick={() => setFormatMode('bin')}
                      className={`hover:text-amber-300 ${formatMode === 'bin' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
                    >
                      BIN
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {error ? (
                    <span className="text-sm font-mono text-rose-400">{error}</span>
                  ) : (
                    <span className="text-2xl sm:text-4xl font-extrabold font-mono text-amber-400 tabular-nums tracking-tight">
                      {getFormattedValue()}
                    </span>
                  )}
                  {result && !error && (
                    <button
                      onClick={handleCopyResult}
                      className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
                      title="Copiar resultado"
                    >
                      {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  )}
                </div>
              </div>

            </div>

            {/* Quick Memory Bar */}
            <div className="px-5 py-2.5 bg-slate-900/50 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const num = Number(result);
                    if (!isNaN(num)) setMemory((m) => m + num);
                  }}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                  title="Somar ao registro de memória (M+)"
                >
                  M+
                </button>
                <button
                  onClick={() => {
                    const num = Number(result);
                    if (!isNaN(num)) setMemory((m) => m - num);
                  }}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                  title="Subtrair do registro de memória (M-)"
                >
                  M-
                </button>
                <button
                  onClick={() => insertText(String(memory))}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                  title="Recuperar memória (MR)"
                >
                  MR
                </button>
                <button
                  onClick={() => setMemory(0)}
                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-rose-400 transition-colors"
                  title="Limpar memória (MC)"
                >
                  MC
                </button>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => onSendToRepl(expression)}
                  className="flex items-center gap-1.5 text-slate-400 hover:text-amber-400 transition-colors"
                  title="Enviar essa expressão para o Terminal Python Interativo"
                >
                  <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
                  <span>Testar no Terminal</span>
                </button>
              </div>
            </div>

            {/* Keypad Grid */}
            <div className="p-4 sm:p-6 grid grid-cols-4 sm:grid-cols-6 gap-2 sm:gap-2.5">
              
              {/* Scientific Rows */}
              <button
                onClick={() => insertText('math.sqrt(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>√x</span>
                <span className="text-[10px] text-slate-400">math.sqrt</span>
              </button>

              <button
                onClick={() => insertText(' ** 2')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>x²</span>
                <span className="text-[10px] text-slate-400">** 2</span>
              </button>

              <button
                onClick={() => insertText(' ** ')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>xʸ</span>
                <span className="text-[10px] text-slate-400">** y</span>
              </button>

              <button
                onClick={() => insertText('math.sin(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>sin</span>
                <span className="text-[10px] text-slate-400">math.sin</span>
              </button>

              <button
                onClick={() => insertText('math.cos(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>cos</span>
                <span className="text-[10px] text-slate-400">math.cos</span>
              </button>

              <button
                onClick={() => insertText('math.tan(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>tan</span>
                <span className="text-[10px] text-slate-400">math.tan</span>
              </button>

              {/* Row 2: Special math */}
              <button
                onClick={() => insertText('math.pi')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>π</span>
                <span className="text-[10px] text-slate-400">3.14159...</span>
              </button>

              <button
                onClick={() => insertText('math.e')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>e</span>
                <span className="text-[10px] text-slate-400">2.71828...</span>
              </button>

              <button
                onClick={() => insertText('math.log(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>ln</span>
                <span className="text-[10px] text-slate-400">math.log</span>
              </button>

              <button
                onClick={() => insertText('math.log10(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>log₁₀</span>
                <span className="text-[10px] text-slate-400">math.log10</span>
              </button>

              <button
                onClick={() => insertText('math.factorial(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>n!</span>
                <span className="text-[10px] text-slate-400">factorial</span>
              </button>

              <button
                onClick={() => insertText('abs(')}
                className="py-3 px-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-mono font-medium transition-colors border border-slate-700/50 hover:border-slate-600 flex flex-col items-center justify-center"
              >
                <span>|x|</span>
                <span className="text-[10px] text-slate-400">abs()</span>
              </button>

              {/* Standard Keypad & Python Operators */}
              <button
                onClick={handleClear}
                className="py-3 px-4 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-mono font-bold transition-colors border border-rose-500/40"
              >
                C
              </button>

              <button
                onClick={handleBackspace}
                className="py-3 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono font-medium transition-colors border border-slate-700/50"
              >
                DEL
              </button>

              <button
                onClick={() => insertText('(')}
                className="py-3 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono font-medium transition-colors border border-slate-700/50"
              >
                (
              </button>

              <button
                onClick={() => insertText(')')}
                className="py-3 px-4 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono font-medium transition-colors border border-slate-700/50"
              >
                )
              </button>

              <button
                onClick={() => insertText(' // ')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-mono font-medium transition-colors border border-slate-700/50 flex flex-col items-center justify-center"
                title="Divisão inteira em Python (//)"
              >
                <span>//</span>
                <span className="text-[10px] text-slate-400">div inteira</span>
              </button>

              <button
                onClick={() => insertText(' % ')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 font-mono font-medium transition-colors border border-slate-700/50 flex flex-col items-center justify-center"
                title="Resto da divisão em Python (%)"
              >
                <span>%</span>
                <span className="text-[10px] text-slate-400">módulo</span>
              </button>

              {/* Digits 7,8,9, / */}
              <button
                onClick={() => insertText('7')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                7
              </button>
              <button
                onClick={() => insertText('8')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                8
              </button>
              <button
                onClick={() => insertText('9')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                9
              </button>
              <button
                onClick={() => insertText(' / ')}
                className="py-3.5 px-4 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-mono text-lg font-bold transition-colors border border-amber-500/30"
              >
                /
              </button>
              <button
                onClick={() => insertText('round(')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-medium transition-colors border border-slate-700/50 flex flex-col items-center justify-center"
              >
                <span>round</span>
                <span className="text-[10px] text-slate-400">arredondar</span>
              </button>
              <button
                onClick={() => insertText('pow(')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-medium transition-colors border border-slate-700/50 flex flex-col items-center justify-center"
              >
                <span>pow</span>
                <span className="text-[10px] text-slate-400">potência</span>
              </button>

              {/* Digits 4,5,6, * */}
              <button
                onClick={() => insertText('4')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                4
              </button>
              <button
                onClick={() => insertText('5')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                5
              </button>
              <button
                onClick={() => insertText('6')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                6
              </button>
              <button
                onClick={() => insertText(' * ')}
                className="py-3.5 px-4 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-mono text-lg font-bold transition-colors border border-amber-500/30"
              >
                *
              </button>
              <button
                onClick={() => insertText('sum([')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-medium transition-colors border border-slate-700/50 flex flex-col items-center justify-center"
              >
                <span>sum</span>
                <span className="text-[10px] text-slate-400">soma lista</span>
              </button>
              <button
                onClick={() => insertText(', ')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-sm font-medium transition-colors border border-slate-700/50 flex items-center justify-center"
              >
                ,
              </button>

              {/* Digits 1,2,3, - */}
              <button
                onClick={() => insertText('1')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                1
              </button>
              <button
                onClick={() => insertText('2')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                2
              </button>
              <button
                onClick={() => insertText('3')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                3
              </button>
              <button
                onClick={() => insertText(' - ')}
                className="py-3.5 px-4 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-mono text-lg font-bold transition-colors border border-amber-500/30"
              >
                -
              </button>
              <button
                onClick={() => insertText('[')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-sm font-medium transition-colors border border-slate-700/50 flex items-center justify-center"
              >
                [
              </button>
              <button
                onClick={() => insertText(']')}
                className="py-3 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-sm font-medium transition-colors border border-slate-700/50 flex items-center justify-center"
              >
                ]
              </button>

              {/* Digits 0, ., +, = */}
              <button
                onClick={() => insertText('0')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                0
              </button>
              <button
                onClick={() => insertText('.')}
                className="py-3.5 px-4 rounded-lg bg-slate-800/50 hover:bg-slate-700/80 text-white font-mono text-lg font-semibold transition-colors border border-slate-800"
              >
                .
              </button>
              <button
                onClick={() => insertText(' + ')}
                className="py-3.5 px-4 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 font-mono text-lg font-bold transition-colors border border-amber-500/30"
              >
                +
              </button>
              <button
                onClick={() => handleCalculate()}
                disabled={isCalculating}
                className="col-span-1 sm:col-span-3 py-3.5 px-6 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-mono text-lg font-bold transition-all shadow-md shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer"
              >
                <CornerDownLeft className="w-5 h-5" />
                <span>Calcular (=)</span>
              </button>

            </div>

            {/* Python Explanation Bar */}
            <div className="bg-slate-950/60 p-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-300">Dica Python:</span>
                <span>Use <code className="text-amber-400 font-mono">**</code> para potência (<code className="text-slate-300">2 ** 3 = 8</code>) e <code className="text-amber-400 font-mono">//</code> para divisão inteira (<code className="text-slate-300">10 // 3 = 3</code>).</span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span>Atalhos:</span>
                <kbd className="px-1.5 py-0.5 bg-slate-800 rounded text-slate-300 border border-slate-700">Enter</kbd>
                <span>calcular</span>
                <kbd className="px-1.5 py-0.5 bg-slate-800 rounded text-slate-300 border border-slate-700">Esc</kbd>
                <span>limpar</span>
              </div>
            </div>

          </div>
        </div>

        {/* History Drawer / Side Panel */}
        {showHistoryDrawer && (
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-amber-400" />
                <h3 className="font-semibold text-white text-sm">Histórico de Operações</h3>
              </div>
              {history.length > 0 && (
                <button
                  onClick={onClearHistory}
                  className="text-xs text-slate-400 hover:text-rose-400 transition-colors flex items-center gap-1"
                  title="Limpar histórico"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Limpar</span>
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                <p>Nenhuma operação gravada no histórico ainda.</p>
                <p className="mt-1 text-slate-400">Faça cálculos para vê-los listados aqui.</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {history.slice(0, 20).map((item) => (
                  <div
                    key={item.id}
                    className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg hover:border-slate-700 transition-colors group"
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                      <span className="font-mono">
                        {item.timestamp.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                      <button
                        onClick={() => {
                          setExpression(item.expression);
                          setResult(String(item.result));
                        }}
                        className="text-amber-400 hover:text-amber-300 opacity-0 group-hover:opacity-100 transition-opacity text-xs"
                      >
                        Recarregar
                      </button>
                    </div>
                    <div className="font-mono text-xs text-slate-300 break-all mb-1">
                      {item.expression}
                    </div>
                    <div className="font-mono text-sm font-bold text-amber-400 text-right">
                      = {formatResultNumber(item.result)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
