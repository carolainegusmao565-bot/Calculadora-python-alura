import React, { useState } from 'react';
import { PYTHON_TEMPLATES, PythonScriptTemplate } from '../data/pythonTemplates';
import { Code2, Download, Copy, Check, FileCode, Terminal, HelpCircle } from 'lucide-react';

interface PythonCodeViewerProps {
  onDownloadFile: (filename: string, content: string) => void;
}

export const PythonCodeViewer: React.FC<PythonCodeViewerProps> = ({ onDownloadFile }) => {
  const [selectedTemplate, setSelectedTemplate] = useState<PythonScriptTemplate>(PYTHON_TEMPLATES[0]);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedTemplate.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Title */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Code2 className="w-6 h-6 text-amber-400" />
            <span>Códigos-Fonte em Python Prontos (.py)</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Scripts completos, testados e comentados em Python 3 para baixar e rodar diretamente no seu computador ou servidor.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-200 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copiado!' : 'Copiar Código'}</span>
          </button>

          <button
            onClick={() => onDownloadFile(selectedTemplate.filename, selectedTemplate.code)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Baixar {selectedTemplate.filename}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Templates Sidebar / Selector */}
        <div className="lg:col-span-4 space-y-3">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Modelos de Calculadora</h2>
          {PYTHON_TEMPLATES.map((tmpl) => {
            const isSelected = selectedTemplate.id === tmpl.id;
            return (
              <div
                key={tmpl.id}
                onClick={() => setSelectedTemplate(tmpl)}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-slate-900 border-amber-500/50 shadow-md'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <h3 className={`text-sm font-semibold ${isSelected ? 'text-amber-400' : 'text-slate-200'}`}>
                    {tmpl.title}
                  </h3>
                  <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                </div>
                <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                  {tmpl.description}
                </p>
                <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                  <span>{tmpl.filename}</span>
                  <span aria-hidden="true">·</span>
                  <span>{tmpl.code.split('\n').length} linhas</span>
                </div>
              </div>
            );
          })}

          {/* Running Instructions Card */}
          <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-4 mt-6">
            <h3 className="text-xs font-bold text-white flex items-center gap-1.5 mb-2">
              <Terminal className="w-3.5 h-3.5 text-amber-400" />
              <span>Como Executar no seu Computador</span>
            </h3>
            <ol className="text-xs text-slate-400 space-y-2 list-decimal list-inside font-sans">
              <li>Instale o Python 3 (<a href="https://www.python.org" target="_blank" rel="noreferrer" className="text-amber-400 hover:underline">python.org</a>).</li>
              <li>Baixe o arquivo clicando no botão acima.</li>
              <li>Abra o terminal na pasta e execute:
                <code className="block mt-1 p-2 bg-slate-950 rounded text-amber-300 font-mono text-[11px] border border-slate-800">
                  python {selectedTemplate.filename}
                </code>
              </li>
            </ol>
          </div>
        </div>

        {/* Code Previewer */}
        <div className="lg:col-span-8">
          <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
            
            {/* Header file bar */}
            <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs">
                <FileCode className="w-4 h-4 text-amber-400" />
                <span className="font-mono text-slate-200 font-semibold">{selectedTemplate.filename}</span>
                <span className="text-slate-500 hidden sm:inline">· Python 3 Script</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <button
                  onClick={handleCopy}
                  className="p-1.5 hover:text-amber-400 text-slate-400 transition-colors flex items-center gap-1"
                  title="Copiar código para a área de transferência"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copiado!' : 'Copiar'}</span>
                </button>
                <button
                  onClick={() => onDownloadFile(selectedTemplate.filename, selectedTemplate.code)}
                  className="p-1.5 hover:text-amber-400 text-slate-400 transition-colors flex items-center gap-1"
                  title="Baixar arquivo .py"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar</span>
                </button>
              </div>
            </div>

            {/* Code Content */}
            <div className="p-4 sm:p-6 overflow-x-auto max-h-[640px] font-mono text-xs sm:text-[13px] leading-relaxed text-slate-200">
              <pre className="whitespace-pre">
                {selectedTemplate.code}
              </pre>
            </div>

            {/* Footer with stats */}
            <div className="bg-slate-900/60 px-4 py-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>{selectedTemplate.code.split('\n').length} linhas de código Python puro</span>
              <span>Encoding: UTF-8</span>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
};
