import React, { useState, useRef, useEffect } from 'react';
import { ReplLogEntry } from '../types';
import { pythonEngine } from '../utils/pythonEvaluator';
import { Terminal, Play, Trash2, Copy, Check, Sparkles, CornerDownLeft } from 'lucide-react';

interface PythonReplProps {
  initialCode?: string;
  isPyodideReady: boolean;
}

const PRESET_SNIPPETS = [
  {
    label: 'Raiz & Potência',
    code: 'import math\na = 2 ** 10\nb = math.sqrt(625)\nprint(f"2^10 = {a}")\nprint(f"√625 = {b}")\na + b',
  },
  {
    label: 'Média de Lista',
    code: 'notas = [8.5, 7.0, 9.2, 6.8, 10.0]\nmedia = sum(notas) / len(notas)\nprint(f"Média das notas: {media:.2f}")',
  },
  {
    label: 'Função Personalizada',
    code: 'def hipotenusa(cateto_a, cateto_b):\n    return (cateto_a**2 + cateto_b**2) ** 0.5\n\nhipotenusa(3, 4)',
  },
  {
    label: 'List Comprehension',
    code: '[x**2 for x in range(1, 11) if x % 2 == 0]',
  },
  {
    label: 'Estatística com statistics',
    code: 'import statistics\ndados = [15, 23, 18, 25, 30, 22, 19]\nprint("Média:", statistics.mean(dados))\nprint("Mediana:", statistics.median(dados))\nprint("Desvio padrão:", round(statistics.stdev(dados), 3))',
  },
];

export const PythonRepl: React.FC<PythonReplProps> = ({ initialCode, isPyodideReady }) => {
  const [logs, setLogs] = useState<ReplLogEntry[]>([
    {
      id: 'welcome-1',
      type: 'system',
      content: 'Python 3.12 Interactive Environment\nDigite expressões ou código Python completo e pressione Executar (ou Ctrl+Enter).',
      timestamp: new Date(),
    },
  ]);
  const [code, setCode] = useState<string>(initialCode || 'salario = 4500\nimposto = salario * 0.15\nsalario_liquido = salario - imposto\nprint(f"Salário Líquido: R$ {salario_liquido:.2f}")\nsalario_liquido');
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [historyCmds, setHistoryCmds] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  const logsEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (initialCode) {
      setCode(initialCode);
    }
  }, [initialCode]);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const handleRunCode = async (customCode?: string) => {
    const codeToRun = (customCode ?? code).trim();
    if (!codeToRun) return;

    setIsExecuting(true);

    // Add input entry
    const inputEntry: ReplLogEntry = {
      id: `in-${Date.now()}`,
      type: 'input',
      content: codeToRun,
      timestamp: new Date(),
    };
    setLogs((prev) => [...prev, inputEntry]);
    setHistoryCmds((prev) => [codeToRun, ...prev.filter((c) => c !== codeToRun)]);
    setHistoryIndex(-1);

    try {
      const result = await pythonEngine.execute(codeToRun);
      
      const newEntries: ReplLogEntry[] = [];
      if (result.stdout) {
        newEntries.push({
          id: `out-stdout-${Date.now()}`,
          type: 'output',
          content: result.stdout,
          timestamp: new Date(),
          durationMs: result.executionTimeMs,
        });
      }

      if (result.result !== '' && result.result !== null && result.result !== undefined) {
        newEntries.push({
          id: `out-res-${Date.now()}`,
          type: 'output',
          content: String(result.result),
          timestamp: new Date(),
          durationMs: result.executionTimeMs,
        });
      }

      if (!result.success || result.stderr) {
        newEntries.push({
          id: `out-err-${Date.now()}`,
          type: 'error',
          content: result.stderr || 'Erro de execução Python',
          timestamp: new Date(),
          durationMs: result.executionTimeMs,
        });
      }

      setLogs((prev) => [...prev, ...newEntries]);
    } catch (err: any) {
      setLogs((prev) => [
        ...prev,
        {
          id: `out-err-${Date.now()}`,
          type: 'error',
          content: err?.message || 'Erro inesperado na execução.',
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsExecuting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Ctrl+Enter or Cmd+Enter to execute
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleRunCode();
      return;
    }

    // Up arrow for history (only if single line or at start)
    if (e.key === 'ArrowUp' && !e.shiftKey && historyCmds.length > 0) {
      const cursor = textareaRef.current?.selectionStart ?? 0;
      if (cursor === 0 || !code.includes('\n')) {
        e.preventDefault();
        const nextIdx = Math.min(historyIndex + 1, historyCmds.length - 1);
        setHistoryIndex(nextIdx);
        setCode(historyCmds[nextIdx]);
      }
    } else if (e.key === 'ArrowDown' && !e.shiftKey && historyIndex >= 0) {
      const cursor = textareaRef.current?.selectionStart ?? 0;
      if (cursor === code.length || !code.includes('\n')) {
        e.preventDefault();
        const prevIdx = historyIndex - 1;
        setHistoryIndex(prevIdx);
        setCode(prevIdx >= 0 ? historyCmds[prevIdx] : '');
      }
    }
  };

  const handleClearTerminal = () => {
    setLogs([
      {
        id: `clear-${Date.now()}`,
        type: 'system',
        content: 'Terminal reiniciado.',
        timestamp: new Date(),
      },
    ]);
  };

  const handleCopyLogs = () => {
    const text = logs
      .map((entry) => {
        if (entry.type === 'input') return `>>> ${entry.content}`;
        if (entry.type === 'output') return entry.content;
        if (entry.type === 'error') return `Traceback (most recent call last):\n${entry.content}`;
        return `# ${entry.content}`;
      })
      .join('\n\n');

    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Header Info */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <Terminal className="w-6 h-6 text-amber-400" />
            <span>Terminal Python Interativo (REPL)</span>
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Execute instruções reais em Python, crie variáveis persistentes, loops, funções personalizadas e importe módulos como <code className="text-amber-400 font-mono">math</code> e <code className="text-amber-400 font-mono">statistics</code>.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyLogs}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors cursor-pointer"
            title="Copiar histórico do terminal"
          >
            {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{isCopied ? 'Copiado!' : 'Copiar Sessão'}</span>
          </button>
          <button
            onClick={handleClearTerminal}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-rose-400 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-lg transition-colors cursor-pointer"
            title="Limpar tela"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Limpar Terminal</span>
          </button>
        </div>
      </div>

      {/* Snippet Pills Bar */}
      <div className="mb-4 flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-500 whitespace-nowrap font-medium">Exemplos rápidos:</span>
        {PRESET_SNIPPETS.map((snippet, idx) => (
          <button
            key={idx}
            onClick={() => {
              setCode(snippet.code);
              handleRunCode(snippet.code);
            }}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-300 border border-slate-800 hover:border-amber-500/30 rounded-lg transition-colors whitespace-nowrap font-mono text-xs cursor-pointer shrink-0"
          >
            {snippet.label}
          </button>
        ))}
      </div>

      {/* Terminal Container */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-2xl flex flex-col h-[640px]">
        
        {/* Terminal Titlebar */}
        <div className="bg-slate-900/90 border-b border-slate-800 px-4 py-3 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-full bg-rose-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
              <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
            </div>
            <span className="font-mono text-slate-300 font-semibold ml-2">python3.12 --interactive</span>
          </div>
          <div className="flex items-center gap-2 font-mono text-[11px]">
            <span>{isPyodideReady ? 'Pyodide WebAssembly' : 'Engine Local'}</span>
            <span aria-hidden="true">·</span>
            <span>UTF-8</span>
          </div>
        </div>

        {/* Scrollable Terminal Output */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 font-mono text-xs sm:text-sm space-y-4">
          {logs.map((entry) => {
            if (entry.type === 'system') {
              return (
                <div key={entry.id} className="text-slate-500 border-b border-slate-800/60 pb-3">
                  <pre className="whitespace-pre-wrap font-mono text-xs">{entry.content}</pre>
                </div>
              );
            }

            if (entry.type === 'input') {
              return (
                <div key={entry.id} className="text-slate-100 flex items-start gap-2">
                  <span className="text-amber-400 select-none font-bold">&gt;&gt;&gt;</span>
                  <pre className="whitespace-pre-wrap font-mono flex-1">{entry.content}</pre>
                </div>
              );
            }

            if (entry.type === 'output') {
              return (
                <div key={entry.id} className="text-emerald-400 pl-6 flex items-start justify-between">
                  <pre className="whitespace-pre-wrap font-mono">{entry.content}</pre>
                  {entry.durationMs !== undefined && (
                    <span className="text-[10px] text-slate-600 select-none ml-2">
                      {entry.durationMs}ms
                    </span>
                  )}
                </div>
              );
            }

            if (entry.type === 'error') {
              return (
                <div key={entry.id} className="text-rose-400 pl-6 bg-rose-950/20 p-2 rounded border border-rose-900/40">
                  <pre className="whitespace-pre-wrap font-mono text-xs">{entry.content}</pre>
                </div>
              );
            }

            return null;
          })}
          <div ref={logsEndRef} />
        </div>

        {/* Terminal Input Bar */}
        <div className="bg-slate-900/90 border-t border-slate-800 p-4">
          <div className="flex items-start gap-3">
            <span className="text-amber-400 font-mono font-bold text-base pt-1 select-none">&gt;&gt;&gt;</span>
            <div className="flex-1">
              <textarea
                ref={textareaRef}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                onKeyDown={handleKeyDown}
                rows={Math.min(code.split('\n').length || 1, 5)}
                placeholder="Escreva código ou expressão Python (ex: [x*2 for x in range(5)])..."
                className="w-full bg-slate-950 text-slate-100 placeholder-slate-600 font-mono text-xs sm:text-sm p-3 rounded-lg border border-slate-800 focus:border-amber-400/60 focus:outline-none resize-none leading-relaxed"
              />
            </div>
            <button
              onClick={() => handleRunCode()}
              disabled={isExecuting || !code.trim()}
              className="px-4 py-3 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-slate-950 font-bold rounded-lg transition-colors flex items-center gap-2 cursor-pointer shrink-0 shadow-sm"
              title="Executar código (Ctrl+Enter)"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span className="hidden sm:inline">Executar</span>
            </button>
          </div>

          <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-500 font-mono">
            <span>Dica: Pressione <kbd className="text-slate-400 bg-slate-800 px-1 py-0.5 rounded">Ctrl + Enter</kbd> para rodar, <kbd className="text-slate-400 bg-slate-800 px-1 py-0.5 rounded">↑</kbd>/<kbd className="text-slate-400 bg-slate-800 px-1 py-0.5 rounded">↓</kbd> para navegar no histórico.</span>
            <span>Variáveis persistem na sessão atual</span>
          </div>
        </div>

      </div>

    </div>
  );
};
