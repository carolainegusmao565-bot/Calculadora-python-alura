import React, { useState } from 'react';
import { Copy, Check, Calculator, ChevronRight, Sigma, TrendingUp, Compass, ArrowRightLeft, Percent } from 'lucide-react';
import { formatResultNumber } from '../utils/pythonEvaluator';

type ActiveFormula = 'porcentagem' | 'bhaskara' | 'juros' | 'estatistica' | 'geometria' | 'conversor';

export const FormulaCalculators: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveFormula>('bhaskara');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // 1. BHASKARA STATE
  const [coefA, setCoefA] = useState<string>('1');
  const [coefB, setCoefB] = useState<string>('-5');
  const [coefC, setCoefC] = useState<string>('6');

  const calculateBhaskara = () => {
    const a = parseFloat(coefA);
    const b = parseFloat(coefB);
    const c = parseFloat(coefC);

    if (isNaN(a) || isNaN(b) || isNaN(c)) {
      return { error: 'Preencha todos os coeficientes com valores numéricos.' };
    }
    if (a === 0) {
      return { error: "O coeficiente 'a' não pode ser zero em uma equação do 2º grau." };
    }

    const delta = b ** 2 - 4 * a * c;
    const xv = -b / (2 * a);
    const yv = -delta / (4 * a);

    let x1: string;
    let x2: string;
    let desc: string;

    if (delta > 0) {
      const raizDelta = Math.sqrt(delta);
      const v1 = (-b + raizDelta) / (2 * a);
      const v2 = (-b - raizDelta) / (2 * a);
      x1 = formatResultNumber(v1);
      x2 = formatResultNumber(v2);
      desc = 'Duas raízes reais e distintas';
    } else if (delta === 0) {
      const v = -b / (2 * a);
      x1 = formatResultNumber(v);
      x2 = formatResultNumber(v);
      desc = 'Uma única raiz real dupla (x₁ = x₂)';
    } else {
      const raizAbs = Math.sqrt(Math.abs(delta));
      const real = (-b / (2 * a)).toFixed(4);
      const imag = (raizAbs / (2 * a)).toFixed(4);
      x1 = `${real} + ${imag}i`;
      x2 = `${real} - ${imag}i`;
      desc = 'Duas raízes complexas conjugadas';
    }

    const pyCode = `import math

def bhaskara(a=${a}, b=${b}, c=${c}):
    delta = b**2 - 4 * a * c
    if delta >= 0:
        x1 = (-b + math.sqrt(delta)) / (2 * a)
        x2 = (-b - math.sqrt(delta)) / (2 * a)
        return {"delta": delta, "x1": x1, "x2": x2}
    else:
        import cmath
        x1 = (-b + cmath.sqrt(delta)) / (2 * a)
        x2 = (-b - cmath.sqrt(delta)) / (2 * a)
        return {"delta": delta, "x1": x1, "x2": x2}

resultado = bhaskara()
print(resultado)`;

    return {
      delta,
      xv: formatResultNumber(xv),
      yv: formatResultNumber(yv),
      x1,
      x2,
      desc,
      concavidade: a > 0 ? 'Para cima (a > 0, ponto de mínimo)' : 'Para baixo (a < 0, ponto de máximo)',
      pyCode,
    };
  };

  // 2. JUROS COMPOSTOS STATE
  const [capitalInicial, setCapitalInicial] = useState<string>('5000');
  const [aporteMensal, setAporteMensal] = useState<string>('300');
  const [taxaJuros, setTaxaJuros] = useState<string>('1.0');
  const [tipoTaxa, setTipoTaxa] = useState<'mes' | 'ano'>('mes');
  const [periodo, setPeriodo] = useState<string>('24');
  const [tipoPeriodo, setTipoPeriodo] = useState<'meses' | 'anos'>('meses');

  const calculateJuros = () => {
    const P = parseFloat(capitalInicial) || 0;
    const PMT = parseFloat(aporteMensal) || 0;
    const taxaInput = parseFloat(taxaJuros) || 0;
    const periodoInput = parseFloat(periodo) || 0;

    // Convert everything to monthly
    const meses = tipoPeriodo === 'anos' ? periodoInput * 12 : periodoInput;
    const i = (tipoTaxa === 'ano' ? (Math.pow(1 + taxaInput / 100, 1 / 12) - 1) : taxaInput / 100);

    let montante = P;
    const evolucao: { mes: number; totalInvestido: number; jurosAcumulados: number; saldo: number }[] = [];
    let totalInvestido = P;

    for (let m = 1; m <= meses; m++) {
      const jurosDoMes = montante * i;
      montante += jurosDoMes + PMT;
      totalInvestido += PMT;

      if (meses <= 24 || m % 6 === 0 || m === meses) {
        evolucao.push({
          mes: m,
          totalInvestido,
          jurosAcumulados: montante - totalInvestido,
          saldo: montante,
        });
      }
    }

    const totalJuros = montante - totalInvestido;

    const pyCode = `def simular_investimento(capital=${P}, aporte=${PMT}, taxa_mensal=${(i * 100).toFixed(4)}, meses=${meses}):
    saldo = capital
    investido = capital
    for _ in range(meses):
        saldo = saldo * (1 + taxa_mensal / 100) + aporte
        investido += aporte
    return {
        "saldo_final": round(saldo, 2),
        "total_investido": round(investido, 2),
        "total_juros": round(saldo - investido, 2)
    }

resultado = simular_investimento()
print(resultado)`;

    return {
      montante: formatResultNumber(montante),
      totalInvestido: formatResultNumber(totalInvestido),
      totalJuros: formatResultNumber(totalJuros),
      evolucao,
      pyCode,
    };
  };

  // 3. ESTATISTICA STATE
  const [statsInput, setStatsInput] = useState<string>('12, 15, 12, 19, 24, 30, 24, 18, 22');

  const calculateStats = () => {
    const numbers = statsInput
      .split(/[\s,;]+/)
      .map((s) => parseFloat(s.trim()))
      .filter((n) => !isNaN(n));

    if (numbers.length === 0) {
      return { error: 'Digite ao menos um número válido.' };
    }

    const n = numbers.length;
    const soma = numbers.reduce((a, b) => a + b, 0);
    const media = soma / n;

    // Median
    const sorted = [...numbers].sort((a, b) => a - b);
    const mid = Math.floor(n / 2);
    const mediana = n % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;

    // Mode
    const freq: Record<number, number> = {};
    numbers.forEach((val) => {
      freq[val] = (freq[val] || 0) + 1;
    });
    let maxFreq = 0;
    Object.values(freq).forEach((f) => {
      if (f > maxFreq) maxFreq = f;
    });
    const modas = Object.keys(freq)
      .filter((k) => freq[Number(k)] === maxFreq && maxFreq > 1)
      .map(Number);

    // Variance & Standard Deviation
    const variancia = n > 1 ? numbers.reduce((acc, val) => acc + (val - media) ** 2, 0) / (n - 1) : 0;
    const desvioPadrao = Math.sqrt(variancia);

    const min = Math.min(...numbers);
    const max = Math.max(...numbers);
    const amplitude = max - min;

    const pyCode = `import statistics

dados = [${numbers.join(', ')}]

print("Contagem (N):", len(dados))
print("Soma:", sum(dados))
print("Média:", statistics.mean(dados))
print("Mediana:", statistics.median(dados))
print("Desvio Padrão:", round(statistics.stdev(dados), 4) if len(dados) > 1 else 0)
print("Variância:", round(statistics.variance(dados), 4) if len(dados) > 1 else 0)
print("Mínimo:", min(dados), "| Máximo:", max(dados))`;

    return {
      n,
      soma: formatResultNumber(soma),
      media: formatResultNumber(media),
      mediana: formatResultNumber(mediana),
      moda: modas.length > 0 ? modas.join(', ') : 'Amodal (todos ocorrem igualmente)',
      variancia: formatResultNumber(variancia),
      desvioPadrao: formatResultNumber(desvioPadrao),
      min: formatResultNumber(min),
      max: formatResultNumber(max),
      amplitude: formatResultNumber(amplitude),
      pyCode,
    };
  };

  // 4. GEOMETRIA STATE
  const [geoSubtype, setGeoSubtype] = useState<'pitagoras' | 'circulo' | 'cilindro'>('pitagoras');
  const [catetoA, setCatetoA] = useState<string>('3');
  const [catetoB, setCatetoB] = useState<string>('4');
  const [raio, setRaio] = useState<string>('5');
  const [alturaCilindro, setAlturaCilindro] = useState<string>('10');

  const calculateGeometria = () => {
    if (geoSubtype === 'pitagoras') {
      const a = parseFloat(catetoA) || 0;
      const b = parseFloat(catetoB) || 0;
      const hipotenusa = Math.sqrt(a ** 2 + b ** 2);
      const area = (a * b) / 2;
      const perimetro = a + b + hipotenusa;
      const pyCode = `import math

def calcular_pitagoras(cat_a=${a}, cat_b=${b}):
    hipotenusa = math.sqrt(cat_a**2 + cat_b**2)
    area = (cat_a * cat_b) / 2
    perimetro = cat_a + cat_b + hipotenusa
    return {"hipotenusa": hipotenusa, "area": area, "perimetro": perimetro}

print(calcular_pitagoras())`;
      return {
        val1: { label: 'Hipotenusa (c)', val: formatResultNumber(hipotenusa) },
        val2: { label: 'Área do Triângulo', val: formatResultNumber(area) },
        val3: { label: 'Perímetro', val: formatResultNumber(perimetro) },
        pyCode,
      };
    } else if (geoSubtype === 'circulo') {
      const r = parseFloat(raio) || 0;
      const diametro = 2 * r;
      const circunferencia = 2 * Math.PI * r;
      const area = Math.PI * r ** 2;
      const pyCode = `import math

def calcular_circulo(raio=${r}):
    diametro = 2 * raio
    circunferencia = 2 * math.pi * raio
    area = math.pi * (raio ** 2)
    return {"diametro": diametro, "circunferencia": circunferencia, "area": area}

print(calcular_circulo())`;
      return {
        val1: { label: 'Diâmetro', val: formatResultNumber(diametro) },
        val2: { label: 'Circunferência (Perímetro)', val: formatResultNumber(circunferencia) },
        val3: { label: 'Área (πr²)', val: formatResultNumber(area) },
        pyCode,
      };
    } else {
      const r = parseFloat(raio) || 0;
      const h = parseFloat(alturaCilindro) || 0;
      const areaBase = Math.PI * r ** 2;
      const volume = areaBase * h;
      const areaLateral = 2 * Math.PI * r * h;
      const areaTotal = 2 * areaBase + areaLateral;
      const pyCode = `import math

def calcular_cilindro(raio=${r}, altura=${h}):
    volume = math.pi * (raio**2) * altura
    area_lateral = 2 * math.pi * raio * altura
    area_total = 2 * math.pi * (raio**2) + area_lateral
    return {"volume": volume, "area_total": area_total}

print(calcular_cilindro())`;
      return {
        val1: { label: 'Volume (V = πr²h)', val: formatResultNumber(volume) },
        val2: { label: 'Área Lateral', val: formatResultNumber(areaLateral) },
        val3: { label: 'Área Superfície Total', val: formatResultNumber(areaTotal) },
        pyCode,
      };
    }
  };

  // 5. CONVERSOR STATE
  const [tempValue, setTempValue] = useState<string>('25');
  const [tempUnit, setTempUnit] = useState<'C' | 'F' | 'K'>('C');

  const convertTemp = () => {
    const val = parseFloat(tempValue) || 0;
    let c = 0;
    let f = 0;
    let k = 0;

    if (tempUnit === 'C') {
      c = val;
      f = (val * 9) / 5 + 32;
      k = val + 273.15;
    } else if (tempUnit === 'F') {
      c = ((val - 32) * 5) / 9;
      f = val;
      k = c + 273.15;
    } else {
      c = val - 273.15;
      f = (c * 9) / 5 + 32;
      k = val;
    }

    const pyCode = `def converter_temperatura(valor=${val}, escala="${tempUnit}"):
    if escala == "C":
        c = valor
    elif escala == "F":
        c = (valor - 32) * 5 / 9
    else:
        c = valor - 273.15
    return {
        "celsius": round(c, 2),
        "fahrenheit": round((c * 9/5) + 32, 2),
        "kelvin": round(c + 273.15, 2)
    }

print(converter_temperatura())`;

    return {
      celsius: formatResultNumber(c),
      fahrenheit: formatResultNumber(f),
      kelvin: formatResultNumber(k),
      pyCode,
    };
  };

  // 6. PORCENTAGEM STATE
  const [percValor, setPercValor] = useState<string>('250');
  const [percTaxa, setPercTaxa] = useState<string>('15');
  const [percOrigem, setPercOrigem] = useState<string>('80');
  const [percDestino, setPercDestino] = useState<string>('100');

  const calculatePorcentagem = () => {
    const valor = parseFloat(percValor) || 0;
    const taxa = parseFloat(percTaxa) || 0;
    const v1 = parseFloat(percOrigem) || 0;
    const v2 = parseFloat(percDestino) || 0;

    const parte = valor * (taxa / 100);
    const comAcrescimo = valor + parte;
    const comDesconto = valor - parte;

    const variacao = v1 !== 0 ? ((v2 - v1) / Math.abs(v1)) * 100 : 0;

    const pyCode = `def calcular_porcentagem(valor=${valor}, taxa=${taxa}):
    parte = valor * (taxa / 100.0)
    com_acrescimo = valor + parte
    com_desconto = valor - parte
    return {
        "parte": parte,
        "com_acrescimo": com_acrescimo,
        "com_desconto": com_desconto
    }

resultado = calcular_porcentagem()
print(f"{${taxa}}% de {${valor}} = {resultado['parte']}")
print(f"Com acréscimo: {resultado['com_acrescimo']}")
print(f"Com desconto: {resultado['com_desconto']}")`;

    return {
      parte: formatResultNumber(parte),
      comAcrescimo: formatResultNumber(comAcrescimo),
      comDesconto: formatResultNumber(comDesconto),
      variacao: formatResultNumber(variacao),
      variacaoSinal: variacao > 0 ? `+${formatResultNumber(variacao)}%` : `${formatResultNumber(variacao)}%`,
      pyCode,
    };
  };

  const bhaskaraRes = calculateBhaskara();
  const jurosRes = calculateJuros();
  const statsRes = calculateStats();
  const geoRes = calculateGeometria();
  const tempRes = convertTemp();
  const percRes = calculatePorcentagem();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      
      {/* Title */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2">
          <Sigma className="w-6 h-6 text-amber-400" />
          <span>Fórmulas Matemáticas Prontas em Python</span>
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Selecione uma calculadora especializada para obter resolução passo a passo, métricas precisas e o código Python correspondente.
        </p>
      </div>

      {/* Tabs navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-6 border-b border-slate-800">
        <button
          onClick={() => setActiveTab('porcentagem')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'porcentagem'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Percent className="w-4 h-4" />
          <span>Porcentagem (%)</span>
        </button>

        <button
          onClick={() => setActiveTab('bhaskara')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'bhaskara'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Calculator className="w-4 h-4" />
          <span>Bhaskara (2º Grau)</span>
        </button>

        <button
          onClick={() => setActiveTab('juros')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'juros'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>Juros Compostos</span>
        </button>

        <button
          onClick={() => setActiveTab('estatistica')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'estatistica'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Sigma className="w-4 h-4" />
          <span>Estatística Descritiva</span>
        </button>

        <button
          onClick={() => setActiveTab('geometria')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'geometria'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Compass className="w-4 h-4" />
          <span>Geometria & Pitágoras</span>
        </button>

        <button
          onClick={() => setActiveTab('conversor')}
          className={`flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            activeTab === 'conversor'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <ArrowRightLeft className="w-4 h-4" />
          <span>Conversor de Unidades</span>
        </button>
      </div>

      {/* CONTENT TABS */}

      {/* 0. PORCENTAGEM */}
      {activeTab === 'porcentagem' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Percent className="w-4 h-4 text-amber-400" />
                  <span>Cálculo de Porcentagem, Acréscimo e Desconto</span>
                </h2>
              </div>
              <p className="text-xs text-slate-400">
                Fórmula básica em Python: <code className="text-amber-400 font-mono">resultado = valor * (taxa / 100)</code>
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Valor Base (Total)</label>
                  <input
                    type="number"
                    value={percValor}
                    onChange={(e) => setPercValor(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                    placeholder="ex: 200"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Porcentagem (%)</label>
                  <input
                    type="number"
                    value={percTaxa}
                    onChange={(e) => setPercTaxa(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                    placeholder="ex: 15"
                  />
                </div>
              </div>

              {/* Resultados */}
              <div className="space-y-3 pt-2">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block">{percTaxa || 0}% de {percValor || 0}</span>
                    <span className="text-xs text-slate-500 font-mono">valor * (taxa / 100)</span>
                  </div>
                  <span className="text-2xl font-bold font-mono text-amber-400">
                    {percRes.parte}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block mb-1">Com Acréscimo (+{percTaxa}%)</span>
                    <span className="text-lg font-bold font-mono text-emerald-400">{percRes.comAcrescimo}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block mb-1">Com Desconto (-{percTaxa}%)</span>
                    <span className="text-lg font-bold font-mono text-rose-400">{percRes.comDesconto}</span>
                  </div>
                </div>
              </div>

              {/* Variação percentual entre dois valores */}
              <div className="pt-4 border-t border-slate-800/80">
                <h3 className="text-xs font-bold text-white mb-2">Variação Percentual (De valor A para valor B)</h3>
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Valor Inicial (A)</label>
                    <input
                      type="number"
                      value={percOrigem}
                      onChange={(e) => setPercOrigem(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2 font-mono text-white text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-mono text-slate-400 mb-1">Valor Final (B)</label>
                    <input
                      type="number"
                      value={percDestino}
                      onChange={(e) => setPercDestino(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2 font-mono text-white text-xs"
                    />
                  </div>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400">Variação de {percOrigem} para {percDestino}:</span>
                  <span className="font-mono font-bold text-amber-400">{percRes.variacaoSinal}</span>
                </div>
              </div>

            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-slate-300 font-semibold">porcentagem.py</span>
                <button
                  onClick={() => copyToClipboard(percRes.pyCode, 'porcentagem')}
                  className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {copiedCode === 'porcentagem' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'porcentagem' ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>
              <div className="p-4 font-mono text-xs overflow-x-auto text-slate-300">
                <pre>{percRes.pyCode}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 1. BHASKARA */}
      {activeTab === 'bhaskara' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 shadow-xl">
              <h2 className="text-base font-bold text-white mb-3">Coeficientes da Equação (ax² + bx + c = 0)</h2>
              
              <div className="grid grid-cols-3 gap-3 mb-4">
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Coeficiente a</label>
                  <input
                    type="number"
                    value={coefA}
                    onChange={(e) => setCoefA(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Coeficiente b</label>
                  <input
                    type="number"
                    value={coefB}
                    onChange={(e) => setCoefB(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-slate-400 mb-1">Coeficiente c</label>
                  <input
                    type="number"
                    value={coefC}
                    onChange={(e) => setCoefC(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                  />
                </div>
              </div>

              {/* Equation display */}
              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800/80 text-center font-mono text-sm text-slate-200">
                <span className="text-amber-400">({coefA || 0})</span>x² +{' '}
                <span className="text-amber-400">({coefB || 0})</span>x +{' '}
                <span className="text-amber-400">({coefC || 0})</span> = 0
              </div>

              {/* Resolution metrics */}
              {'error' in bhaskaraRes ? (
                <div className="mt-4 p-3 bg-rose-950/20 text-rose-400 rounded-lg border border-rose-900/50 text-xs font-mono">
                  {bhaskaraRes.error}
                </div>
              ) : (
                <div className="mt-5 space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                      <span className="text-xs text-slate-400 block mb-1">Discriminante (Δ)</span>
                      <span className="text-lg font-bold font-mono text-amber-400">{bhaskaraRes.delta}</span>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                      <span className="text-xs text-slate-400 block mb-1">Natureza das Raízes</span>
                      <span className="text-xs font-medium text-slate-200">{bhaskaraRes.desc}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                      <span className="text-xs text-slate-400 block mb-1">Primeira Raiz (x₁)</span>
                      <span className="text-xl font-bold font-mono text-emerald-400">{bhaskaraRes.x1}</span>
                    </div>
                    <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                      <span className="text-xs text-slate-400 block mb-1">Segunda Raiz (x₂)</span>
                      <span className="text-xl font-bold font-mono text-emerald-400">{bhaskaraRes.x2}</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400">Vértice da Parábola:</span>
                    <span className="font-mono text-slate-200 font-semibold">
                      (Xv = {bhaskaraRes.xv}, Yv = {bhaskaraRes.yv})
                    </span>
                  </div>

                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between text-xs">
                    <span className="text-slate-400">Concavidade:</span>
                    <span className="text-slate-200 font-medium">{bhaskaraRes.concavidade}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-slate-300 font-semibold">bhaskara.py</span>
                <button
                  onClick={() => bhaskaraRes.pyCode && copyToClipboard(bhaskaraRes.pyCode, 'bhaskara')}
                  className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {copiedCode === 'bhaskara' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'bhaskara' ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>
              <div className="p-4 font-mono text-xs overflow-x-auto text-slate-300">
                <pre>{bhaskaraRes.pyCode}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. JUROS COMPOSTOS */}
      {activeTab === 'juros' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 shadow-xl space-y-4">
              <h2 className="text-base font-bold text-white">Parâmetros do Investimento</h2>
              
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">Capital Inicial (R$)</label>
                <input
                  type="number"
                  value={capitalInicial}
                  onChange={(e) => setCapitalInicial(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">Aporte Mensal (R$)</label>
                <input
                  type="number"
                  value={aporteMensal}
                  onChange={(e) => setAporteMensal(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Taxa de Juros (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={taxaJuros}
                    onChange={(e) => setTaxaJuros(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Período da Taxa</label>
                  <select
                    value={tipoTaxa}
                    onChange={(e: any) => setTipoTaxa(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 text-white text-sm"
                  >
                    <option value="mes">Ao Mês (% a.m.)</option>
                    <option value="ano">Ao Ano (% a.a.)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Prazo</label>
                  <input
                    type="number"
                    value={periodo}
                    onChange={(e) => setPeriodo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Unidade do Prazo</label>
                  <select
                    value={tipoPeriodo}
                    onChange={(e: any) => setTipoPeriodo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 text-white text-sm"
                  >
                    <option value="meses">Meses</option>
                    <option value="anos">Anos</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 shadow-xl">
              <h2 className="text-base font-bold text-white mb-4">Resultado da Simulação Financeira</h2>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Montante Final</span>
                  <span className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 tabular-nums">
                    R$ {jurosRes.montante}
                  </span>
                </div>
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Total Investido</span>
                  <span className="text-lg font-bold font-mono text-slate-200 tabular-nums">
                    R$ {jurosRes.totalInvestido}
                  </span>
                </div>
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800">
                  <span className="text-xs text-slate-400 block mb-1">Ganho em Juros</span>
                  <span className="text-lg font-bold font-mono text-amber-400 tabular-nums">
                    R$ {jurosRes.totalJuros}
                  </span>
                </div>
              </div>

              {/* Table sample */}
              <div className="overflow-x-auto max-h-56">
                <table className="w-full text-xs text-left font-mono">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 sticky top-0">
                    <tr>
                      <th className="py-2 px-3">Mês</th>
                      <th className="py-2 px-3 text-right">Investido</th>
                      <th className="py-2 px-3 text-right">Juros Acumulados</th>
                      <th className="py-2 px-3 text-right">Saldo Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {jurosRes.evolucao.map((row) => (
                      <tr key={row.mes} className="hover:bg-slate-800/40">
                        <td className="py-2 px-3 text-slate-300">Mês {row.mes}</td>
                        <td className="py-2 px-3 text-right text-slate-400">R$ {formatResultNumber(row.totalInvestido)}</td>
                        <td className="py-2 px-3 text-right text-amber-400">R$ {formatResultNumber(row.jurosAcumulados)}</td>
                        <td className="py-2 px-3 text-right font-bold text-emerald-400">R$ {formatResultNumber(row.saldo)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-slate-300 font-semibold">juros_compostos.py</span>
                <button
                  onClick={() => copyToClipboard(jurosRes.pyCode, 'juros')}
                  className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {copiedCode === 'juros' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'juros' ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>
              <div className="p-4 font-mono text-xs overflow-x-auto text-slate-300">
                <pre>{jurosRes.pyCode}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. ESTATISTICA */}
      {activeTab === 'estatistica' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 shadow-xl">
              <h2 className="text-base font-bold text-white mb-2">Conjunto de Dados Numéricos</h2>
              <p className="text-xs text-slate-400 mb-3">
                Digite números separados por vírgula, espaço ou ponto e vírgula:
              </p>
              
              <textarea
                value={statsInput}
                onChange={(e) => setStatsInput(e.target.value)}
                rows={3}
                className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-3 font-mono text-white text-sm resize-none mb-4"
                placeholder="ex: 10, 15, 20, 25, 30"
              />

              {'error' in statsRes ? (
                <div className="p-3 bg-rose-950/20 text-rose-400 rounded-lg border border-rose-900/50 text-xs font-mono">
                  {statsRes.error}
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block">Amostras (N)</span>
                    <span className="text-lg font-bold font-mono text-white">{statsRes.n}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block">Soma Total</span>
                    <span className="text-lg font-bold font-mono text-white">{statsRes.soma}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block">Média Aritmética</span>
                    <span className="text-lg font-bold font-mono text-amber-400">{statsRes.media}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block">Mediana</span>
                    <span className="text-lg font-bold font-mono text-emerald-400">{statsRes.mediana}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block">Desvio Padrão (σ)</span>
                    <span className="text-lg font-bold font-mono text-emerald-400">{statsRes.desvioPadrao}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block">Variância Amostral</span>
                    <span className="text-lg font-bold font-mono text-white">{statsRes.variancia}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                    <span className="text-xs text-slate-400 block">Mínimo / Máximo</span>
                    <span className="text-xs font-mono text-slate-300 font-bold">{statsRes.min} a {statsRes.max}</span>
                  </div>
                  <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 sm:col-span-2">
                    <span className="text-xs text-slate-400 block">Moda</span>
                    <span className="text-xs font-mono text-slate-300 font-bold">{statsRes.moda}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-slate-300 font-semibold">estatistica_python.py</span>
                <button
                  onClick={() => statsRes.pyCode && copyToClipboard(statsRes.pyCode, 'stats')}
                  className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {copiedCode === 'stats' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'stats' ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>
              <div className="p-4 font-mono text-xs overflow-x-auto text-slate-300">
                <pre>{statsRes.pyCode}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. GEOMETRIA */}
      {activeTab === 'geometria' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 shadow-xl">
              <div className="flex items-center gap-2 mb-4 p-1 bg-slate-950 rounded-lg border border-slate-800">
                <button
                  onClick={() => setGeoSubtype('pitagoras')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    geoSubtype === 'pitagoras' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Pitágoras (Triângulo)
                </button>
                <button
                  onClick={() => setGeoSubtype('circulo')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    geoSubtype === 'circulo' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Círculo
                </button>
                <button
                  onClick={() => setGeoSubtype('cilindro')}
                  className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                    geoSubtype === 'cilindro' ? 'bg-amber-400 text-slate-950' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Cilindro 3D
                </button>
              </div>

              {geoSubtype === 'pitagoras' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1">Cateto A</label>
                      <input
                        type="number"
                        value={catetoA}
                        onChange={(e) => setCatetoA(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1">Cateto B</label>
                      <input
                        type="number"
                        value={catetoB}
                        onChange={(e) => setCatetoB(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                      />
                    </div>
                  </div>
                </div>
              )}

              {geoSubtype === 'circulo' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-400 mb-1">Raio do Círculo (r)</label>
                    <input
                      type="number"
                      value={raio}
                      onChange={(e) => setRaio(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                    />
                  </div>
                </div>
              )}

              {geoSubtype === 'cilindro' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1">Raio da Base (r)</label>
                      <input
                        type="number"
                        value={raio}
                        onChange={(e) => setRaio(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-400 mb-1">Altura (h)</label>
                      <input
                        type="number"
                        value={alturaCilindro}
                        onChange={(e) => setAlturaCilindro(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Geo Results */}
              <div className="mt-5 space-y-3">
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400">{geoRes.val1.label}</span>
                  <span className="text-base font-bold font-mono text-amber-400">{geoRes.val1.val}</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400">{geoRes.val2.label}</span>
                  <span className="text-base font-bold font-mono text-emerald-400">{geoRes.val2.val}</span>
                </div>
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400">{geoRes.val3.label}</span>
                  <span className="text-base font-bold font-mono text-white">{geoRes.val3.val}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-slate-300 font-semibold">geometria.py</span>
                <button
                  onClick={() => copyToClipboard(geoRes.pyCode, 'geo')}
                  className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {copiedCode === 'geo' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'geo' ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>
              <div className="p-4 font-mono text-xs overflow-x-auto text-slate-300">
                <pre>{geoRes.pyCode}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. CONVERSOR */}
      {activeTab === 'conversor' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 sm:p-6 shadow-xl space-y-4">
              <h2 className="text-base font-bold text-white">Conversor de Temperatura</h2>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Valor de Entrada</label>
                  <input
                    type="number"
                    value={tempValue}
                    onChange={(e) => setTempValue(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 font-mono text-white text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">Escala Original</label>
                  <select
                    value={tempUnit}
                    onChange={(e: any) => setTempUnit(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 focus:border-amber-400 rounded-lg p-2.5 text-white text-sm"
                  >
                    <option value="C">Celsius (°C)</option>
                    <option value="F">Fahrenheit (°F)</option>
                    <option value="K">Kelvin (K)</option>
                  </select>
                </div>
              </div>

              <div className="mt-6 space-y-3">
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Celsius</span>
                  <span className="text-xl font-bold font-mono text-emerald-400">{tempRes.celsius} °C</span>
                </div>
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Fahrenheit</span>
                  <span className="text-xl font-bold font-mono text-amber-400">{tempRes.fahrenheit} °F</span>
                </div>
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-400">Kelvin</span>
                  <span className="text-xl font-bold font-mono text-white">{tempRes.kelvin} K</span>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-6">
            <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
              <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between text-xs">
                <span className="font-mono text-slate-300 font-semibold">conversor_temperatura.py</span>
                <button
                  onClick={() => copyToClipboard(tempRes.pyCode, 'temp')}
                  className="flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors"
                >
                  {copiedCode === 'temp' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode === 'temp' ? 'Copiado!' : 'Copiar Código'}</span>
                </button>
              </div>
              <div className="p-4 font-mono text-xs overflow-x-auto text-slate-300">
                <pre>{tempRes.pyCode}</pre>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
