import React from 'react';
import { CalculatorMode } from '../types';
import { Download, Code2, Terminal, Calculator, Sigma } from 'lucide-react';

interface HeaderProps {
  currentMode: CalculatorMode;
  onSelectMode: (mode: CalculatorMode) => void;
  onDownloadScript: () => void;
  isPyodideReady: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  currentMode,
  onSelectMode,
  onDownloadScript,
  isPyodideReady,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-slate-950 font-mono font-black text-sm shadow-sm">
            py
          </div>
          <button
            onClick={() => onSelectMode('calculator')}
            className="text-lg font-bold tracking-tight text-white hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <span>Calculadora Python</span>
          </button>
        </div>

        {/* Zone 2: Nav Tabs (4 clean single-line modes) */}
        <nav className="flex items-center gap-1 sm:gap-2">
          <button
            onClick={() => onSelectMode('calculator')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentMode === 'calculator'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>Calculadora</span>
          </button>

          <button
            onClick={() => onSelectMode('repl')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentMode === 'repl'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Terminal REPL</span>
          </button>

          <button
            onClick={() => onSelectMode('formulas')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentMode === 'formulas'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Sigma className="w-4 h-4" />
            <span>Fórmulas Prontas</span>
          </button>

          <button
            onClick={() => onSelectMode('code')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              currentMode === 'code'
                ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>Código .py</span>
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="hidden xl:flex items-center gap-2 text-xs text-slate-400">
            <span>Python 3.12</span>
            <span aria-hidden="true">·</span>
            <span>{isPyodideReady ? 'Pyodide WASM' : 'Math Engine'}</span>
          </div>
          <button
            onClick={onDownloadScript}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
            title="Baixar calculadora completa em Python (.py)"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Baixar Script .py</span>
            <span className="sm:hidden">.py</span>
          </button>
        </div>

      </div>
    </header>
  );
};
