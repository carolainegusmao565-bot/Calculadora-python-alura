export interface PythonScriptTemplate {
  id: string;
  title: string;
  filename: string;
  description: string;
  tags: string[];
  code: string;
}

export const PYTHON_TEMPLATES: PythonScriptTemplate[] = [
  {
    id: 'basic_percentage_calculator',
    title: 'Calculadora 4 Operações + Porcentagem (Terminal)',
    filename: 'calculadora_porcentagem.py',
    description: 'As 4 operações fundamentais (+, -, *, /) acrescidas da operação de porcentagem (%), cálculo de desconto e acréscimo.',
    tags: ['4 Operações', 'Porcentagem', 'Iniciante', 'Terminal'],
    code: `"""
Calculadora Básica com 4 Operações e Porcentagem em Python
Execução: python calculadora_porcentagem.py
"""

def somar(a, b):
    return a + b

def subtrair(a, b):
    return a - b

def multiplicar(a, b):
    return a * b

def dividir(a, b):
    if b == 0:
        raise ZeroDivisionError("Divisão por zero não é permitida.")
    return a / b

def porcentagem(valor, taxa):
    """Calcula taxa% de um valor. Exemplo: 15% de 200 = 30.0"""
    return valor * (taxa / 100.0)

def exibir_menu():
    print("\\n" + "=" * 35)
    print("      CALCULADORA COM PORCENTAGEM")
    print("=" * 35)
    print("1 - Soma (+)")
    print("2 - Subtração (-)")
    print("3 - Multiplicação (*)")
    print("4 - Divisão (/)")
    print("5 - Porcentagem (%)")
    print("0 - Sair")
    print("=" * 35)

def main():
    while True:
        exibir_menu()
        opcao = input("Escolha uma opção (0 a 5): ").strip()
        
        if opcao == "0":
            print("\\nPrograma encerrado. Até mais!")
            break
            
        if opcao not in ("1", "2", "3", "4", "5"):
            print("❌ Opção inválida! Escolha um número de 0 a 5.")
            continue
            
        try:
            if opcao == "5":
                valor = float(input("Digite o valor base: "))
                taxa = float(input("Digite a taxa percentual (%): "))
                resultado = porcentagem(valor, taxa)
                
                print(f"\\n✅ {taxa}% de {valor} = {resultado}")
                print(f"   • Valor com acréscimo (+{taxa}%): {valor + resultado}")
                print(f"   • Valor com desconto (-{taxa}%): {valor - resultado}")
            else:
                num1 = float(input("Digite o primeiro número: "))
                num2 = float(input("Digite o segundo número: "))
                
                if opcao == "1":
                    print(f"\\n✅ Resultado: {num1} + {num2} = {somar(num1, num2)}")
                elif opcao == "2":
                    print(f"\\n✅ Resultado: {num1} - {num2} = {subtrair(num1, num2)}")
                elif opcao == "3":
                    print(f"\\n✅ Resultado: {num1} * {num2} = {multiplicar(num1, num2)}")
                elif opcao == "4":
                    print(f"\\n✅ Resultado: {num1} / {num2} = {dividir(num1, num2)}")
                    
        except ValueError:
            print("❌ Erro: Digite apenas números válidos!")
        except ZeroDivisionError as err:
            print(f"❌ Erro: {err}")

if __name__ == "__main__":
    main()
`,
  },
  {
    id: 'cli_calculator',
    title: 'Calculadora Completa no Terminal (CLI)',
    filename: 'calculadora_terminal.py',
    description: 'Calculadora interativa via linha de comando com menu, tratamento de erros robusto (try/except) e suporte a histórico.',
    tags: ['Terminal', 'Básico ao Avançado', 'Tratamento de Erros'],
    code: `"""
Calculadora Interativa em Python (CLI)
Execução: python calculadora_terminal.py
"""

import math

def exibir_menu():
    print("\\n" + "=" * 40)
    print("        CALCULADORA EM PYTHON")
    print("=" * 40)
    print("1. Adição (+)")
    print("2. Subtração (-)")
    print("3. Multiplicação (*)")
    print("4. Divisão (/)")
    print("5. Potência (x^y)")
    print("6. Raiz Quadrada (√)")
    print("7. Divisão Inteira (//)")
    print("8. Resto da Divisão / Módulo (%)")
    print("9. Fatorial (n!)")
    print("10. Seno, Cosseno, Tangente")
    print("11. Ver Histórico")
    print("0. Sair")
    print("=" * 40)

def obter_numero(mensagem="Digite um número: "):
    while True:
        try:
            return float(input(mensagem))
        except ValueError:
            print("❌ Entrada inválida! Digite um valor numérico.")

def main():
    historico = []
    
    print("Bem-vindo à Calculadora em Python!")
    
    while True:
        exibir_menu()
        opcao = input("Escolha uma opção (0-11): ").strip()
        
        if opcao == "0":
            print("\\nObrigado por usar a calculadora! Encerrando...")
            break
            
        elif opcao in ("1", "2", "3", "4", "5", "7", "8"):
            num1 = obter_numero("Primeiro número: ")
            num2 = obter_numero("Segundo número: ")
            
            try:
                if opcao == "1":
                    resultado = num1 + num2
                    operacao = f"{num1} + {num2} = {resultado}"
                elif opcao == "2":
                    resultado = num1 - num2
                    operacao = f"{num1} - {num2} = {resultado}"
                elif opcao == "3":
                    resultado = num1 * num2
                    operacao = f"{num1} * {num2} = {resultado}"
                elif opcao == "4":
                    if num2 == 0:
                        raise ZeroDivisionError("Divisão por zero não é permitida.")
                    resultado = num1 / num2
                    operacao = f"{num1} / {num2} = {resultado}"
                elif opcao == "5":
                    resultado = num1 ** num2
                    operacao = f"{num1} ** {num2} = {resultado}"
                elif opcao == "7":
                    if num2 == 0:
                        raise ZeroDivisionError("Divisão por zero não é permitida.")
                    resultado = num1 // num2
                    operacao = f"{num1} // {num2} = {resultado}"
                elif opcao == "8":
                    if num2 == 0:
                        raise ZeroDivisionError("Módulo por zero não é permitido.")
                    resultado = num1 % num2
                    operacao = f"{num1} % {num2} = {resultado}"
                    
                print(f"\\n✅ Resultado: {resultado}")
                historico.append(operacao)
            except ZeroDivisionError as erro:
                print(f"\\n❌ Erro: {erro}")
            except OverflowError:
                print("\\n❌ Erro: Número excessivamente grande para calcular!")

        elif opcao == "6":
            num = obter_numero("Digite o número para raiz: ")
            if num < 0:
                print("\\n❌ Não é possível calcular raiz quadrada real de número negativo!")
            else:
                resultado = math.sqrt(num)
                operacao = f"√{num} = {resultado}"
                print(f"\\n✅ Resultado: {resultado}")
                historico.append(operacao)

        elif opcao == "9":
            try:
                n = int(input("Digite um inteiro positivo para fatorial: "))
                if n < 0:
                    print("❌ Fatorial só existe para números inteiros não-negativos.")
                else:
                    resultado = math.factorial(n)
                    operacao = f"{n}! = {resultado}"
                    print(f"\\n✅ Resultado: {resultado}")
                    historico.append(operacao)
            except ValueError:
                print("❌ Entrada inválida! Digite um número inteiro.")

        elif opcao == "10":
            ang = obter_numero("Digite o ângulo em graus: ")
            rad = math.radians(ang)
            seno = math.sin(rad)
            cosseno = math.cos(rad)
            tangente = math.tan(rad) if abs(cosseno) > 1e-10 else "Indefinida (90° ou 270°)"
            print(f"\\nPara o ângulo de {ang}°:")
            print(f"• Seno: {seno:.5f}")
            print(f"• Cosseno: {cosseno:.5f}")
            print(f"• Tangente: {tangente if isinstance(tangente, str) else f'{tangente:.5f}'}")
            historico.append(f"Trigonometria({ang}°): sen={seno:.4f}, cos={cosseno:.4f}")

        elif opcao == "11":
            print("\\n📜 Histórico de Cálculos:")
            if not historico:
                print("Nenhum cálculo realizado ainda.")
            else:
                for i, item in enumerate(historico, 1):
                    print(f"  {i}. {item}")
        else:
            print("❌ Opção inválida! Escolha um número do menu.")

if __name__ == "__main__":
    main()
`,
  },
  {
    id: 'poo_calculator',
    title: 'Calculadora Orientada a Objetos (POO)',
    filename: 'calculadora_poo.py',
    description: 'Estruturada em classes e métodos, seguindo boas práticas PEP 8, anotações de tipo (Type Hints) e testes unitários.',
    tags: ['POO', 'Type Hints', 'PEP 8', 'Testes'],
    code: `"""
Calculadora Orientada a Objetos em Python
Padrão profissional com Type Hints, Docstrings e Testes
"""

from typing import List, Optional
import math

class Calculadora:
    """Classe responsável por operações aritméticas e científicas."""

    def __init__(self) -> None:
        self._historico: List[str] = []
        self._memoria: float = 0.0

    def somar(self, a: float, b: float) -> float:
        """Retorna a soma de dois números."""
        res = a + b
        self._salvar_historico(f"{a} + {b} = {res}")
        return res

    def subtrair(self, a: float, b: float) -> float:
        """Retorna a diferença entre dois números."""
        res = a - b
        self._salvar_historico(f"{a} - {b} = {res}")
        return res

    def multiplicar(self, a: float, b: float) -> float:
        """Retorna o produto de dois números."""
        res = a * b
        self._salvar_historico(f"{a} * {b} = {res}")
        return res

    def dividir(self, a: float, b: float) -> float:
        """Retorna o quociente da divisão. Lança ZeroDivisionError se b for 0."""
        if b == 0:
            raise ZeroDivisionError("Não é possível dividir por zero.")
        res = a / b
        self._salvar_historico(f"{a} / {b} = {res}")
        return res

    def potencia(self, base: float, expoente: float) -> float:
        """Eleva a base ao expoente fornecido."""
        res = base ** expoente
        self._salvar_historico(f"{base} ** {expoente} = {res}")
        return res

    def raiz_quadrada(self, x: float) -> float:
        """Calcula a raiz quadrada de um número real não-negativo."""
        if x < 0:
            raise ValueError("Não existe raiz real para números negativos.")
        res = math.sqrt(x)
        self._salvar_historico(f"sqrt({x}) = {res}")
        return res

    def porcentagem(self, valor: float, percentual: float) -> float:
        """Calcula percentual de um valor (ex: 20% de 500 = 100)."""
        res = valor * (percentual / 100.0)
        self._salvar_historico(f"{percentual}% de {valor} = {res}")
        return res

    # Operações de memória
    def memoria_salvar(self, valor: float) -> None:
        self._memoria = valor

    def memoria_ler(self) -> float:
        return self._memoria

    def memoria_adicionar(self, valor: float) -> None:
        self._memoria += valor

    def memoria_limpar(self) -> None:
        self._memoria = 0.0

    @property
    def historico(self) -> List[str]:
        """Retorna uma cópia do histórico de operações."""
        return list(self._historico)

    def _salvar_historico(self, registro: str) -> None:
        self._historico.append(registro)

    def limpar_historico(self) -> None:
        self._historico.clear()


# Demonstração e Testes
if __name__ == "__main__":
    calc = Calculadora()
    
    print("--- Teste de Operações Básicas ---")
    print("10 + 5 =", calc.somar(10, 5))
    print("20 - 7 =", calc.subtrair(20, 7))
    print("6 * 8 =", calc.multiplicar(6, 8))
    print("100 / 4 =", calc.dividir(100, 4))
    print("2 ** 8 =", calc.potencia(2, 8))
    print("√144 =", calc.raiz_quadrada(144))
    print("15% de 200 =", calc.porcentagem(200, 15))
    
    print("\\n--- Histórico de Cálculos ---")
    for item in calc.historico:
        print("•", item)
`,
  },
  {
    id: 'gui_tkinter',
    title: 'Calculadora Gráfica com Interface Desktop (Tkinter)',
    filename: 'calculadora_gui.py',
    description: 'Aplicativo desktop pronto com janela gráfica moderna usando Tkinter (biblioteca nativa do Python, sem necessidade de pip install).',
    tags: ['Tkinter', 'Desktop', 'Interface Gráfica', 'Nativo'],
    code: `"""
Calculadora Gráfica com Tkinter em Python
Execução direta: python calculadora_gui.py
Não requer instalação de pacotes externos!
"""

import tkinter as tk
from tkinter import ttk, messagebox
import math

class CalculadoraGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Calculadora Python")
        self.root.geometry("360x520")
        self.root.resizable(False, False)
        self.root.configure(bg="#0f172a")

        self.expressao = ""
        self.variavel_display = tk.StringVar(value="0")

        self._criar_interface()
        self._configurar_teclado()

    def _criar_interface(self):
        # Frame do Display
        display_frame = tk.Frame(self.root, bg="#1e293b", padx=16, py=20)
        display_frame.pack(fill="x", padx=14, pady=14)

        # Rótulo de título Python
        lbl_info = tk.Label(
            display_frame,
            text="Python 3 Math Engine",
            font=("JetBrains Mono", 9),
            fg="#94a3b8",
            bg="#1e293b",
            anchor="e"
        )
        lbl_info.pack(fill="x")

        # Display principal
        display = tk.Entry(
            display_frame,
            textvariable=self.variavel_display,
            font=("JetBrains Mono", 24, "bold"),
            bg="#1e293b",
            fg="#f8fafc",
            bd=0,
            justify="right",
            state="readonly"
        )
        display.pack(fill="x", pady=(4, 0))

        # Grid dos Botões
        btn_frame = tk.Frame(self.root, bg="#0f172a")
        btn_frame.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        botoes = [
            ("C", self.limpar, "#ef4444", "#ffffff"),
            ("(", lambda: self.inserir("("), "#334155", "#f8fafc"),
            (")", lambda: self.inserir(")"), "#334155", "#f8fafc"),
            ("/", lambda: self.inserir("/"), "#f59e0b", "#0f172a"),
            
            ("7", lambda: self.inserir("7"), "#1e293b", "#f8fafc"),
            ("8", lambda: self.inserir("8"), "#1e293b", "#f8fafc"),
            ("9", lambda: self.inserir("9"), "#1e293b", "#f8fafc"),
            ("*", lambda: self.inserir("*"), "#f59e0b", "#0f172a"),
            
            ("4", lambda: self.inserir("4"), "#1e293b", "#f8fafc"),
            ("5", lambda: self.inserir("5"), "#1e293b", "#f8fafc"),
            ("6", lambda: self.inserir("6"), "#1e293b", "#f8fafc"),
            ("-", lambda: self.inserir("-"), "#f59e0b", "#0f172a"),
            
            ("1", lambda: self.inserir("1"), "#1e293b", "#f8fafc"),
            ("2", lambda: self.inserir("2"), "#1e293b", "#f8fafc"),
            ("3", lambda: self.inserir("3"), "#1e293b", "#f8fafc"),
            ("+", lambda: self.inserir("+"), "#f59e0b", "#0f172a"),
            
            ("0", lambda: self.inserir("0"), "#1e293b", "#f8fafc"),
            (".", lambda: self.inserir("."), "#1e293b", "#f8fafc"),
            ("^", lambda: self.inserir("**"), "#334155", "#f8fafc"),
            ("=", self.calcular, "#10b981", "#ffffff")
        ]

        # Configura as 4 colunas com peso igual
        for i in range(4):
            btn_frame.columnconfigure(i, weight=1, uniform="btn")
        for i in range(5):
            btn_frame.rowconfigure(i, weight=1, uniform="btn")

        linha = 0
        coluna = 0
        for texto, comando, cor_fundo, cor_texto in botoes:
            btn = tk.Button(
                btn_frame,
                text=texto,
                command=comando,
                font=("JetBrains Mono", 14, "bold"),
                bg=cor_fundo,
                fg=cor_texto,
                activebackground="#475569",
                activeforeground="#ffffff",
                relief="flat",
                bd=0,
                cursor="hand2"
            )
            btn.grid(row=linha, column=coluna, sticky="nsew", padx=3, pady=3)
            coluna += 1
            if coluna > 3:
                coluna = 0
                linha += 1

    def _configurar_teclado(self):
        self.root.bind("<Return>", lambda event: self.calcular())
        self.root.bind("<BackSpace>", lambda event: self.apagar_ultimo())
        self.root.bind("<Escape>", lambda event: self.limpar())
        for char in "0123456789+-*/.()":
            self.root.bind(char, lambda event, c=char: self.inserir(c))

    def inserir(self, valor: str):
        self.expressao += str(valor)
        self.variavel_display.set(self.expressao)

    def apagar_ultimo(self):
        self.expressao = self.expressao[:-1]
        self.variavel_display.set(self.expressao if self.expressao else "0")

    def limpar(self):
        self.expressao = ""
        self.variavel_display.set("0")

    def calcular(self):
        if not self.expressao:
            return
        try:
            # Avaliação segura com math embutido
            ambiente_seguro = {
                "math": math,
                "sqrt": math.sqrt,
                "sin": math.sin,
                "cos": math.cos,
                "pi": math.pi,
                "e": math.e,
                "abs": abs,
                "round": round
            }
            resultado = eval(self.expressao, {"__builtins__": {}}, ambiente_seguro)
            
            # Limpa float e formata
            if isinstance(resultado, float) and resultado.is_integer():
                resultado = int(resultado)
                
            self.expressao = str(resultado)
            self.variavel_display.set(self.expressao)
        except ZeroDivisionError:
            messagebox.showerror("Erro de Cálculo", "Divisão por zero não é permitida.")
            self.limpar()
        except Exception:
            messagebox.showerror("Erro de Sintaxe", "Expressão matemática inválida.")
            self.limpar()

if __name__ == "__main__":
    janela = tk.Tk()
    app = CalculadoraGUI(janela)
    janela.mainloop()
`,
  },
  {
    id: 'bhaskara_py',
    title: 'Script de Bhaskara / Equação do 2º Grau',
    filename: 'bhaskara.py',
    description: 'Resolve equações ax² + bx + c = 0 calculando delta, raízes reais ou complexas e o vértice da parábola.',
    tags: ['Matemática', 'Álgebra', 'Bhaskara'],
    code: `"""
Calculador de Equações do Segundo Grau (Fórmula de Bhaskara)
ax² + bx + c = 0
"""

import cmath
import math

def resolver_bhaskara(a: float, b: float, c: float):
    if a == 0:
        raise ValueError("O coeficiente 'a' não pode ser 0 em uma equação do 2º grau.")

    delta = b**2 - 4 * a * c
    print(f"\\nEquação: ({a})x² + ({b})x + ({c}) = 0")
    print(f"Δ (Delta) = {b}² - 4*({a})*({c}) = {delta}")

    x_vertice = -b / (2 * a)
    y_vertice = -delta / (4 * a)
    print(f"Vértice da Parábola: (Xv = {x_vertice:.4f}, Yv = {y_vertice:.4f})")

    if delta > 0:
        x1 = (-b + math.sqrt(delta)) / (2 * a)
        x2 = (-b - math.sqrt(delta)) / (2 * a)
        print("Duas raízes reais e distintas:")
        print(f"  x₁ = {x1:.6f}")
        print(f"  x₂ = {x2:.6f}")
        return x1, x2
    elif delta == 0:
        x = -b / (2 * a)
        print(f"Uma raiz real dupla: x = {x:.6f}")
        return x, x
    else:
        raiz_delta = cmath.sqrt(delta)
        x1 = (-b + raiz_delta) / (2 * a)
        x2 = (-b - raiz_delta) / (2 * a)
        print("Duas raízes complexas:")
        print(f"  x₁ = {x1}")
        print(f"  x₂ = {x2}")
        return x1, x2

if __name__ == "__main__":
    print("--- Calculadora de Bhaskara ---")
    try:
        a = float(input("Digite o coeficiente a: "))
        b = float(input("Digite o coeficiente b: "))
        c = float(input("Digite o coeficiente c: "))
        resolver_bhaskara(a, b, c)
    except ValueError as e:
        print(f"Erro: {e}")
`,
  },
];
