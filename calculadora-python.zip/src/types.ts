export type CalculatorMode = 'calculator' | 'repl' | 'formulas' | 'code';

export interface CalculationHistoryItem {
  id: string;
  timestamp: Date;
  expression: string;
  pythonCode: string;
  result: string | number;
  type: 'basic' | 'scientific' | 'repl' | 'formula';
}

export interface ReplLogEntry {
  id: string;
  type: 'input' | 'output' | 'error' | 'system';
  content: string;
  timestamp: Date;
  durationMs?: number;
}

export interface FormulaResult {
  title: string;
  values: { label: string; value: string | number; note?: string }[];
  pythonCode: string;
  steps?: string[];
}
