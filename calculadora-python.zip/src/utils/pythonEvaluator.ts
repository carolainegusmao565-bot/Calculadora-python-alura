/**
 * Python execution engine supporting both Pyodide WebAssembly
 * and an instant client-side math evaluator fallback.
 */

declare global {
  interface Window {
    loadPyodide?: (config: { indexURL: string }) => Promise<any>;
    pyodideInstance?: any;
  }
}

interface RunResult {
  success: boolean;
  result: any;
  stdout?: string;
  stderr?: string;
  executionTimeMs: number;
}

class PythonEngine {
  private pyodide: any = null;
  private isLoading = false;
  private isLoaded = false;
  private persistentScope: Record<string, any> = {
    pi: Math.PI,
    e: Math.E,
  };

  constructor() {
    this.initPyodide();
  }

  public async initPyodide(): Promise<boolean> {
    if (this.isLoaded) return true;
    if (this.isLoading) return false;

    if (typeof window === 'undefined') return false;

    this.isLoading = true;
    try {
      // Check if pyodide script is already injected
      if (!window.loadPyodide) {
        await new Promise<void>((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.js';
          script.async = true;
          script.onload = () => resolve();
          script.onerror = () => reject(new Error('Failed to load Pyodide script'));
          document.head.appendChild(script);
        });
      }

      if (window.loadPyodide) {
        this.pyodide = await window.loadPyodide({
          indexURL: 'https://cdn.jsdelivr.net/pyodide/v0.27.2/full/',
        });
        // Import math and statistics standard libraries
        await this.pyodide.runPythonAsync(`
import math
import sys
import io
import statistics
import random
`);
        this.isLoaded = true;
        this.isLoading = false;
        return true;
      }
    } catch {
      // Graceful fallback to client-side evaluator
      this.isLoading = false;
      this.isLoaded = false;
    }
    return false;
  }

  public isPyodideReady(): boolean {
    return this.isLoaded;
  }

  public async execute(code: string): Promise<RunResult> {
    const startTime = performance.now();
    const cleanCode = code.trim();

    if (!cleanCode) {
      return {
        success: true,
        result: '',
        executionTimeMs: 0,
      };
    }

    // Try full Pyodide first if ready
    if (this.pyodide) {
      try {
        const setupCapture = `
__stdout_capture = io.StringIO()
__stderr_capture = io.StringIO()
sys.stdout = __stdout_capture
sys.stderr = __stderr_capture
`;
        await this.pyodide.runPythonAsync(setupCapture);

        // Run user code
        let evalResult = await this.pyodide.runPythonAsync(cleanCode);

        // Retrieve stdout/stderr
        const stdout = await this.pyodide.runPythonAsync('__stdout_capture.getvalue()');
        const stderr = await this.pyodide.runPythonAsync('__stderr_capture.getvalue()');
        await this.pyodide.runPythonAsync(`
sys.stdout = sys.__stdout__
sys.stderr = sys.__stderr__
`);

        let formattedResult = '';
        if (evalResult !== undefined && evalResult !== null) {
          // Convert PyProxy if needed
          if (typeof evalResult.toJs === 'function') {
            try {
              evalResult = evalResult.toJs();
            } catch {
              evalResult = String(evalResult);
            }
          }
          formattedResult = String(evalResult);
        }

        const endTime = performance.now();
        return {
          success: !stderr,
          result: formattedResult,
          stdout: stdout || undefined,
          stderr: stderr || undefined,
          executionTimeMs: Math.round(endTime - startTime),
        };
      } catch (err: any) {
        const endTime = performance.now();
        return {
          success: false,
          result: null,
          stderr: err?.message || String(err),
          executionTimeMs: Math.round(endTime - startTime),
        };
      }
    }

    // Fallback: Instant client-side Python math interpreter
    try {
      const fallbackResult = this.evaluateFallback(cleanCode);
      const endTime = performance.now();
      return {
        success: true,
        result: fallbackResult.value,
        stdout: fallbackResult.stdout,
        executionTimeMs: Math.round(endTime - startTime),
      };
    } catch (err: any) {
      const endTime = performance.now();
      return {
        success: false,
        result: null,
        stderr: err?.message || 'Erro de sintaxe Python',
        executionTimeMs: Math.round(endTime - startTime),
      };
    }
  }

  /**
   * Fast mathematical fallback parser supporting Python math syntax:
   * ** (power), // (floor div), % (modulo), math.* functions, variables.
   */
  private evaluateFallback(code: string): { value: string; stdout?: string } {
    const lines = code.split('\n').map((l) => l.trim()).filter(Boolean);
    let lastResult = '';
    const stdoutLines: string[] = [];

    // Helper math environment
    const mathEnv: Record<string, any> = {
      math: {
        sqrt: Math.sqrt,
        sin: Math.sin,
        cos: Math.cos,
        tan: Math.tan,
        asin: Math.asin,
        acos: Math.acos,
        atan: Math.atan,
        log: Math.log,
        log10: Math.log10,
        log2: Math.log2,
        exp: Math.exp,
        pow: Math.pow,
        pi: Math.PI,
        e: Math.E,
        ceil: Math.ceil,
        floor: Math.floor,
        radians: (deg: number) => (deg * Math.PI) / 180,
        degrees: (rad: number) => (rad * 180) / Math.PI,
        factorial: (n: number) => {
          if (n < 0 || !Number.isInteger(n)) throw new Error('math.factorial() aceita apenas inteiros não negativos');
          let r = 1;
          for (let i = 2; i <= n; i++) r *= i;
          return r;
        },
      },
      abs: Math.abs,
      round: (val: number, dec: number = 0) => Number(val.toFixed(dec)),
      sum: (arr: number[]) => (Array.isArray(arr) ? arr.reduce((a, b) => a + b, 0) : arr),
      min: (...args: any[]) => (Array.isArray(args[0]) ? Math.min(...args[0]) : Math.min(...args)),
      max: (...args: any[]) => (Array.isArray(args[0]) ? Math.max(...args[0]) : Math.max(...args)),
      len: (arr: any) => (arr ? arr.length || Object.keys(arr).length : 0),
      pi: Math.PI,
      e: Math.E,
      print: (...args: any[]) => {
        stdoutLines.push(args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' '));
      },
      ...this.persistentScope,
    };

    for (const rawLine of lines) {
      if (rawLine.startsWith('#')) continue;

      // Handle variable assignment e.g. x = 10
      const assignMatch = rawLine.match(/^([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(.+)$/);
      if (assignMatch) {
        const varName = assignMatch[1];
        const expr = assignMatch[2];
        const val = this.evalExpression(expr, mathEnv);
        mathEnv[varName] = val;
        this.persistentScope[varName] = val;
        lastResult = `${varName} = ${val}`;
        continue;
      }

      // Check if print(...)
      if (rawLine.startsWith('print(') && rawLine.endsWith(')')) {
        const inner = rawLine.slice(6, -1);
        const val = this.evalExpression(inner, mathEnv);
        stdoutLines.push(String(val));
        lastResult = '';
        continue;
      }

      const res = this.evalExpression(rawLine, mathEnv);
      if (res !== undefined) {
        // Clean float precision
        if (typeof res === 'number') {
          lastResult = String(cleanFloat(res));
        } else {
          lastResult = typeof res === 'object' ? JSON.stringify(res) : String(res);
        }
      }
    }

    return {
      value: lastResult,
      stdout: stdoutLines.length ? stdoutLines.join('\n') : undefined,
    };
  }

  private evalExpression(expr: string, context: Record<string, any>): any {
    // Convert Python operators to JS
    let jsExpr = expr
      // Python // floor division: a // b -> Math.floor(a / b)
      .replace(/(\b\w+|\([^()]+\))\s*\/\/\s*(\b\w+|\([^()]+\))/g, 'Math.floor($1 / $2)')
      // Python ** power operator: a ** b -> (a ** b)
      .replace(/\*\*/g, '**');

    // Create safe function with context keys
    const keys = Object.keys(context);
    const values = Object.values(context);

    try {
      const fn = new Function(...keys, `"use strict"; return (${jsExpr});`);
      return fn(...values);
    } catch {
      throw new Error(`SyntaxError: expressao invalida "${expr}"`);
    }
  }
}

export function cleanFloat(num: number): number {
  if (!Number.isFinite(num)) return num;
  return Number(Math.round(Number(num + 'e+12')) + 'e-12');
}

export function formatResultNumber(val: number | string): string {
  if (typeof val === 'string') {
    const num = Number(val);
    if (!isNaN(num) && val.trim() !== '') {
      return formatResultNumber(num);
    }
    return val;
  }
  if (!Number.isFinite(val)) return String(val);
  if (Math.abs(val) >= 1e12 || (Math.abs(val) > 0 && Math.abs(val) < 1e-6)) {
    return val.toExponential(6);
  }
  // Standard format with up to 10 decimal digits
  const cleaned = cleanFloat(val);
  return new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 10 }).format(cleaned);
}

export const pythonEngine = new PythonEngine();
