import React, { useState, useEffect } from 'react';
import { CalculatorMode, CalculationHistoryItem } from './types';
import { Header } from './components/Header';
import { VisualCalculator } from './components/VisualCalculator';
import { PythonRepl } from './components/PythonRepl';
import { FormulaCalculators } from './components/FormulaCalculators';
import { PythonCodeViewer } from './components/PythonCodeViewer';
import { PYTHON_TEMPLATES } from './data/pythonTemplates';
import { pythonEngine } from './utils/pythonEvaluator';

export default function App() {
  const [currentMode, setCurrentMode] = useState<CalculatorMode>('calculator');
  const [isPyodideReady, setIsPyodideReady] = useState<boolean>(false);
  const [replInitialCode, setReplInitialCode] = useState<string>('');

  // History state with local storage persistence
  const [history, setHistory] = useState<CalculationHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('python_calc_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        return parsed.map((item: any) => ({
          ...item,
          timestamp: new Date(item.timestamp),
        }));
      }
    } catch {
      // Ignore fallback
    }
    return [];
  });

  // Check Pyodide engine initialization status
  useEffect(() => {
    const checkEngine = () => {
      if (pythonEngine.isPyodideReady()) {
        setIsPyodideReady(true);
      }
    };
    const interval = setInterval(checkEngine, 1000);
    return () => clearInterval(interval);
  }, []);

  // Save history changes
  useEffect(() => {
    try {
      localStorage.setItem('python_calc_history', JSON.stringify(history));
    } catch {
      // Ignore
    }
  }, [history]);

  const handleAddHistory = (item: CalculationHistoryItem) => {
    setHistory((prev) => [item, ...prev.slice(0, 49)]);
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem('python_calc_history');
    } catch {
      // Ignore
    }
  };

  // Bridge between Calculator and REPL
  const handleSendToRepl = (code: string) => {
    setReplInitialCode(code);
    setCurrentMode('repl');
  };

  // Download .py file utility
  const handleDownloadFile = (filename: string, content: string) => {
    const blob = new Blob([content], { type: 'text/x-python;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownloadPrimaryScript = () => {
    const defaultTemplate = PYTHON_TEMPLATES[0];
    handleDownloadFile(defaultTemplate.filename, defaultTemplate.code);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500/20 selection:text-amber-300">
      
      {/* Top Bar Navigation */}
      <Header
        currentMode={currentMode}
        onSelectMode={setCurrentMode}
        onDownloadScript={handleDownloadPrimaryScript}
        isPyodideReady={isPyodideReady}
      />

      {/* Main Mode View */}
      <main className="flex-1">
        {currentMode === 'calculator' && (
          <VisualCalculator
            onSendToRepl={handleSendToRepl}
            history={history}
            onAddHistory={handleAddHistory}
            onClearHistory={handleClearHistory}
          />
        )}

        {currentMode === 'repl' && (
          <PythonRepl
            initialCode={replInitialCode}
            isPyodideReady={isPyodideReady}
          />
        )}

        {currentMode === 'formulas' && (
          <FormulaCalculators />
        )}

        {currentMode === 'code' && (
          <PythonCodeViewer onDownloadFile={handleDownloadFile} />
        )}
      </main>

      {/* Quiet, Clean Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">Calculadora em Python</span>
            <span aria-hidden="true">·</span>
            <span>Ambiente Matemático & Scripts Prontos</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Python 3.12 Standard Library</span>
            <span aria-hidden="true">·</span>
            <span>Módulos <code className="text-slate-300 font-mono">math</code>, <code className="text-slate-300 font-mono">statistics</code></span>
          </div>
        </div>
      </footer>

    </div>
  );
}
